
import java.util.Scanner;

public class Calculadora {

    public static void main(String[] args) {
        Calculando calculadora = new Calculando();
        Scanner scan = new Scanner(System.in);


        System.out.println("CALCULADORA AUTOMÀTICA! INFORME DOIS NÙMEROS!!!");
        System.out.println("Informe o primeiro número: ");
        calculadora.setNumero1(scan.nextDouble());
        System.out.println("Informe o segundo número: ");
        calculadora.setNumero2(scan.nextDouble());

        calculadora.soma();
        calculadora.subtracao();
        calculadora.divisao();
        calculadora.multiplicacao();

    }
}
